#Name: Satish Dodda
#uild: sdodda1
#pledge: This entire code was written by Satish Dodda 
#copyright: 2024 satish Dodda, unauthorized copying or modiying the code is not allowed

# rna_folding method will accepts sequence as input and it will find valid pair's from rna sequence using dynamic programming and it will return all valid paris
# @sequence is a string , which contains a rna sequence 
# Satish Dodda , 29-oct-2024 started at 2pm finsihed at 3pm
def rna_folding(sequence):
    # finding the length of the sequence 
    n = len(sequence)
    # filling the 2d list initially it is filled with 0 
    table = [[0] * n for i in range(n)]
    #pair is a dictionary which  contians valid rna pairs 
    pair = {'A': 'U', 'U': 'A', 'C': 'G', 'G': 'C'}
    #track is 2d list which is initially willed with None 
    track = [[None] * n for i in range(n)]
    #this loop controls the length of the subsequence being evaluated
    for length in range(5, n): 
        #this is loop is used to define the staring position of the sequence 
        for i in range(n - length):
            # j is used to determine the ending position of the sequence 
            j = i + length
            #initially we will assume that j is not paired at  so we will copy the values of previous cell 
            table[i][j] = table[i][j - 1]  
            #this loop is used to find valid pair between j and t ensuring that there is a minimum distance of 4 positions between t and j
            for t in range(i, j - 4):  
                # if sequence[t]==pair[sequence[j]] if itt found a valid pair then it will enter into if condition 
                if sequence[t] == pair.get(sequence[j], ''):  
                    #if above conditon is true that means we found an valid pair so it will add one to  score 
                    #if there is a valid sequence from i to t-1 then it will add  that score 
                    #if there is a valid sequence from t+1 to j-1 then it will add that score 
                    score = 1 + (table[i][t - 1] if t > i else 0) + table[t + 1][j - 1]
                    #if score is greater than current value in table update the table value with score 
                    # t is the position of a valid pair  with j so update the t in track 
                    if score > table[i][j]:
                        table[i][j] = score
                        track[i][j] = t 
    #method get_pairs which will accepts i, j variable as parameters and it will  find all valid pairs from track table using bracktracking and it will return it                     
    #@ i,j are vairables which represents the starting and ending indexs of sequence 
    #Satish Dodda , 29-oct-2024 started at 2:40pm finsihed at 3pm
    def get_pairs(i, j):
        #if i>=j or table[i][j]==0 which means invalid or empty sequence so it will return empty list back
        if i >= j or table[i][j] == 0:
            return []
        # if we found an valid pair 
        if track[i][j] is not None:
            #t is the position of base pair 
            t = track[i][j]
            #it will store the t, i in list and recurssively find any addition valid pairs in the sequence from i to t-1 and t+1 to j-1 
            return [(t, j)] + get_pairs(i, t - 1) + get_pairs(t + 1, j - 1)
        # if not found a valid pair for i to j then it will try to find valid pairs from i to j-1 
        return get_pairs(i, j - 1)

    pairs = get_pairs(0, n - 1)
    # returning the pairs and total number of valid pairs 
    return pairs, table[0][n - 1]


import sys

print(f"Folding RNA in file {sys.argv[1]}\n")

file=open(sys.argv[1])
sequence = ""
s = ""
# reading line by line from file
for line in file:
    # if ** is found then it means staring of the test case 
    if '**' in line: 
        s = line.strip()
    # if a or c or g or u in line means that is the sequence 
    elif 'A' in line or 'C' in line or 'G' in line or 'U' in line: 
        sequence = line.strip()
        print(f'{s[0:2]} {s[2:-1]}, length={len(line.strip())}, Optimal secondary structure:')
        # passing sequence to the rna_folding method 
        pairs, max_pairs = rna_folding(sequence)
        #sorting the pairs      
        pairs.sort()
        #printing the pairs 
        for i, j in pairs:
            print(f"{sequence[i]}-{sequence[j]} ({i + 1},{j + 1})")
        print(f"Total number of base pairs: {max_pairs}\n")
print("By Satish Dodda")

 